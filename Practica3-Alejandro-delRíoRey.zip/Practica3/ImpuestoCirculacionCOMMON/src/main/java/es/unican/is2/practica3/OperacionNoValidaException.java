package es.unican.is2.practica3;

@SuppressWarnings("serial")
public class OperacionNoValidaException extends RuntimeException {

	public OperacionNoValidaException(String string) {
		super(string);
	}

}
